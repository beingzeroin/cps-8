#include "avl.h"
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <assert.h>

AVLNode *createAVLNode(int data)
{
    AVLNode *n = malloc(sizeof(AVLNode));
    n->left = n->right = NULL;
    n->data = data;
    n->balanceFactor = 0;
    return n;
}
AVLNode *insertAVL(AVLNode *root, int data)
{
    assert(false);
    return NULL;
}
AVLNode *searchAVL(AVLNode *root, int data)
{
    assert(false);
    return NULL;
}
AVLNode *deleteAVL(AVLNode *root, int data)
{
    assert(false);
    return NULL;
}
void inorderAVL(AVLNode *root)
{
    assert(false);
 }

AVLNode *createRandomAVLTree(int nodeCount)
{
    AVLNode *root = NULL;
    int i;
    for(i=1;i<=nodeCount;i++)
        root = insertAVL(root, rand());
    return root;
}
