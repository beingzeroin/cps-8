#include "BST.h"
#include <stdlib.h>

BSTNode *createBSTNode(ElementType data)
{
   return NULL;
}

BSTNode *rinsertBSTNode(BSTNode *root, ElementType data)
{
    return NULL;
}

BSTNode *insertBSTNode(BSTNode *root, ElementType data)
{
    return NULL;
}

BSTNode *delteBSTNode(BSTNode *root, ElementType data)
{
    return NULL;
}
