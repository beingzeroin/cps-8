#include "LLNode.h"
#include <stdlib.h>
#include <assert.h>
#include <stdbool.h>

LLNode* createLLNode(ElementType data)
{
    assert(false);
    return NULL;
}

LLNode* insertInBegin(LLNode *head, ElementType data)
{
    assert(false);
    return NULL;
}

LLNode* deleteFirstNode(LLNode *head)
{
    assert(false);
    return NULL;
}

LLNode* destroyAllNodes(LLNode *head)
{
   assert(false);
   return NULL;
}
