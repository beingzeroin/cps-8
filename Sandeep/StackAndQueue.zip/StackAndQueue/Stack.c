#include "Stack.h"
#include <stdlib.h>
#include <assert.h>

Stack *createStack()
{
    assert(false);
    return NULL;
}

void push(Stack *s, ElementType data)
{
    assert(false);
}

ElementType pop(Stack *s)
{
    ElementType a;
    assert(false);
    return a;
}

ElementType peek(Stack *s)
{
    ElementType a;
    assert(false);
    return a;
}

bool isStackEmpty(Stack *s)
{
    assert(false);
    return false;
}

Stack * destroyStack(Stack *s)
{
   assert(false);
   return NULL;
}

int getStackElementCount(Stack *s)
{
    assert(false);
    return 0;
}
