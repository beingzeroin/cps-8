#include "Queue.h"
#include <stdlib.h>
#include <assert.h>

Queue *createQueue()
{
    assert(false);
    return NULL;
}

void enqueue(Queue* q, ElementType data)
{
    assert(false);
}

ElementType dequeue(Queue *q)
{
    assert(false);
    ElementType a;
    return a;
}

bool isQueueEmpty(Queue *q)
{
    assert(false);
    return false;
}
Queue *destroyQueue(Queue *q)
{
   assert(false);
    return NULL;
}
