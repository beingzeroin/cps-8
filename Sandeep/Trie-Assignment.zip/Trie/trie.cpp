#include "trie.h"
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

TNode *createTrieNode()
{
    assert(false);
}

bool rinsertWordInTrie(TNode *root, char *word)
{
    assert(false);
}
bool insertWordInTrie(TNode *root, char *word)
{
    assert(false);
}

void printWordsInTrie(TNode *root)
{
    assert(false);
}

bool deleteWordFromTrie(TNode *root,char *word)
{
    assert(false);
}

bool isLeaf(TNode *root)
{
    for(int i=0;i<ALPHABET_SIZE;i++)
        if(root->next[i]!=NULL)
            return false;
    return true;
}
















