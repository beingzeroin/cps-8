#include <iostream>
#include "trie.h"
#include <stdio.h>
#include <assert.h>

using namespace std;

TNode *getTrieByInsertionIterative()
{
    TNode *root = createTrieNode();

    insertWordInTrie(root, "apple");
    insertWordInTrie(root, "car");
    insertWordInTrie(root, "cars");
    insertWordInTrie(root, "cart");
    insertWordInTrie(root, "carts");
    insertWordInTrie(root, "beingzero");
    insertWordInTrie(root, "apple");
    insertWordInTrie(root, "banana");
    insertWordInTrie(root, "chiku");
    insertWordInTrie(root, "car");
    insertWordInTrie(root, "cart");
    insertWordInTrie(root, "carts");

    return root;
}


TNode *getTrieByInsertionRecursive()
{
    TNode *root = createTrieNode();

    rinsertWordInTrie(root, "apple");
    rinsertWordInTrie(root, "car");
    rinsertWordInTrie(root, "cars");
    rinsertWordInTrie(root, "cart");
    rinsertWordInTrie(root, "carts");
    rinsertWordInTrie(root, "beingzero");
    rinsertWordInTrie(root, "apple");
    rinsertWordInTrie(root, "banana");
    rinsertWordInTrie(root, "chiku");
    rinsertWordInTrie(root, "car");
    rinsertWordInTrie(root, "cart");
    rinsertWordInTrie(root, "carts");

    return root;
}

void unitTestsInsertAndPrint(){

    TNode *root = getTrieByInsertionIterative();

    printWordsInTrie(root);
    printf("\n\n");
}

void unitTestsDeleteAndPrint()
{

    TNode *root = getTrieByInsertionIterative();

    printWordsInTrie(root);


    deleteWordFromTrie(root, "apple");
    deleteWordFromTrie(root, "car");
    deleteWordFromTrie(root, "carts");
    deleteWordFromTrie(root, "zoo");
    deleteWordFromTrie(root, "ca");
    deleteWordFromTrie(root, "cart");
    deleteWordFromTrie(root, "");

    printf("\n\n");
    printWordsInTrie(root);
}
int main()
{
    // EXERCISE - 1
    // MAKE THE UNIT TESTS WORK - INSERTION
    unitTestsInsertAndPrint();

    // EXERCISE - 2
    // Insert in Trie from a File

    // EXERCISE - 3
    // Print all words starting with given prefix


    // EXERCISE - 4
    // MAKE THE UNIT TESTS WORK - DELETION
    // unitTestsDeleteAndPrint();

    return 0;
}
